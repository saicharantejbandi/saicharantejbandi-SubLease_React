import React from 'react';

import classes from './Toolbar.css';

const toolbar = ( props ) => (
    <header className={classes.Toolbar}>
        
        THE SUBLEASER
    </header>
);

export default toolbar;