import React from 'react';

import classes from "./Post.css";

const post = (props) => (
  
    <article className={classes.Post} onClick={props.clicked}>

        <h1>{props.title}</h1>

        <div className={classes.Info}>
            <div className={classes.Author}>Posted By:{props.author}</div>
            <p><span role="img" aria-label="dolalr">💲</span>:{props.price}</p>
            <p>Rooms: {props.rooms}</p>
            <p> <span role="img" aria-label="smoking">🚬</span>: {(props.smoking ==='true' ? <span role="img" aria-label="tick">✔️</span> 
             :<span role="img" aria-label="ban">🚫</span> )}</p>
            <p>Pets: {props.pets==='true'? <span role="img" aria-label="tick">✔️</span> 
             :<span role="img" aria-label="ban">🚫</span> }</p>
            <p>From: {props.moveIn}</p>
            <p>To:{props.moveOut}</p>
            <p><span role="img" aria-label="email">📧</span> :{props.email}</p>
            <p><span role="img" aria-label="address">🏠</span>:{props.street+', '+props.city+', '+props.zipCode}</p>
        </div>
    </article>
);

export default post;