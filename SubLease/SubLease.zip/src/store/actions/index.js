

export {
   auth,
   logout,
   authFail,
   authSuccess,
   authStart,
   setAuthRedirectPath,
   authCheckState
} from './auth';

export {
   fetchPosts
} from './posts'

export{
   newPost
} from './newPost'