import React, { Component } from 'react';
import axios from '../../../axios';
import { Route } from 'react-router-dom';

import Post from '../../../components/Post/Post';
import './Posts.css';
import FullPost from '../FullPost/FullPost';

class Posts extends Component {
    state = {
        posts: []
    }

    componentDidMount () {
        console.log( 'here' );
        axios.get( '/posts.json' )
            .then( response => {
                console.log(response.data);
                const posts = response.data;
                const fetchedOrders=[];
                for (let key in response.data){
                    fetchedOrders.push({
                        ...response.data[key],
                        id:key
                    })
                }
                console.log(fetchedOrders);
                const updatedPosts = fetchedOrders.map( post => {
                    return {
                        ...post,
                        
                    }
                } );
                
                this.setState( { posts: updatedPosts } );
                // console.log( response );
            } )
            .catch( error => {
                console.log( error );
                // this.setState({error: true});
            } );
    }

    postSelectedHandler = ( id ) => {
        // this.props.history.push({pathname: '/posts/' + id});
        this.props.history.push( '/posts/' + id );
    }

    render () {
        let posts = <p style={{ textAlign: 'center' }}>Something went wrong!</p>;
        if ( !this.state.error ) {
            posts = this.state.posts.map( post => {
                return (
                    // <Link to={'/posts/' + post.id} key={post.id}>
                    <Post
                        key={post.id}
                        title={post.title}
                        author={post.author}
                        details={post.content}
                        /* clicked={() => this.postSelectedHandler( post.id )} */ />
                    // </Link>
                );
            } );
        }

        return (
            <div>
                <section className="Posts">
                    <h1>POSTS</h1>
                    {posts}
                </section>
                <Route path={this.props.match.url + '/:id'} exact component={FullPost} />
            </div>
        );
    }
}

export default Posts;