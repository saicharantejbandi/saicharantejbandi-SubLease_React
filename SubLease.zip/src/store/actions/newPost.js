import axios from 'axios';
import * as actions from './actionTypes';
import {storage} from '../../firebase/index';


export const newPostStart =() =>{
    return{
        type:actions.NEWPOST_START
    }
}

export const newPostSuccess =() =>{
    return {
        type:actions.NEWPOST_SUCCESS
    }
}

export const newPostFail = (error) =>{
    return {
        type:actions.NEWPOST_FAIL,
        error:error
    }
}
let urlLink=null;
let errImg=null;
const handleUpload = (image) =>{
    const uploadTask = storage.ref(`images/${image.name}`)
    .put(image);
    uploadTask.on(
        "state_changed",
        snapshot => {
            const progress = Math.round(
                (snapshot.bytesTransferred/snapshot.totalBytes)*100
            );
            this.setState({progress:progress});
        },
        error =>{
            console.log(error);
            errImg=error.message;
        },
        ()=>{
            storage
            .ref('images')
            .child(this.state.image.name)
            .getDownloadURL()
            .then(url =>{
                console.log(url);
                urlLink=url;
                this.setState({url:url});
            })
        }
    )

  };




export const newPost= (post, token,image) =>{
    return dispatch =>{
        dispatch(newPostStart());

        axios.post('https://react-my-burger-4ff3d.firebaseio.com/posts.json', post)
        .then(responce => {
            dispatch(newPostSuccess());
        })
        .catch(error =>{
            dispatch(newPostFail(error.message))
        })
    }
}