import React, { Component } from 'react';
// import axios from 'axios';
import { NavLink} from 'react-router-dom';

import classes from './Layout.css'



class Layout extends Component {
    state = {
        auth: true
    }

    render () {
        return (
            <div className={classes.Blog}>
                <header>
                    <nav>
                        <ul>
                            <li><NavLink
                                to="/posts"
                                exact
                                activeClassName="my-active"
                                activeStyle={{
                                    color: '#fa923f',
                                    textDecoration: 'underline'
                                }}>Posts</NavLink></li>
                            <li><NavLink to={{
                                pathname: '/new-post',
                               
                            }}>New Post</NavLink></li>
                            <li><NavLink to={{
                                pathname: '/auth',
                               
                            }}>Login/Sign Up</NavLink></li>

                        </ul>
                    </nav>
                </header>
              
                
            </div>
        );
    }
}

export default Layout;